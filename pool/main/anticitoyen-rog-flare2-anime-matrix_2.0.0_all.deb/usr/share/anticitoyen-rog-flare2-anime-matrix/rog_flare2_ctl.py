#!/usr/bin/env python3
"""animematrix-ctl — commande le démon animematrixd (et bibliothèque client).

    animematrix-ctl etat
    animematrix-ctl gif [DOSSIER|FICHIER...] [--originaux] [--une-fois]
    animematrix-ctl effet NOM [--param clé=valeur ...] [--cadence 1.5]
    animematrix-ctl horloge
    animematrix-ctl texte "Bonjour"              (texte défilant en lecture de base)
    animematrix-ctl notifier "Nouveau mail" [--duree 6]
    animematrix-ctl luminosite 60
    animematrix-ctl stop
    animematrix-ctl derniere                     (rejoue la dernière lecture)
    animematrix-ctl memoire FICHIER [--reduire couper|alterner] [--fidele]
                                                 (enregistre dans le clavier : affichée sans logiciel)
    animematrix-ctl clavier [1-7]                (animation du clavier : 7 l'enregistrée, 1-6 les intégrées)
    animematrix-ctl sauvegarde reglages.zip [--secrets] / restaurer reglages.zip
    animematrix-ctl rgb arc-en-ciel [--vitesse 50] [--luminosite 100] [--direction gauche]
    animematrix-ctl rgb statique --couleur "#ff0000"    (touches : effets du clavier, theme, pulsation)
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from rog_flare2_demon import SHOW_FILE, SOCKET_PATH  # noqa: E402


class DaemonError(RuntimeError):
    pass


def request(cmd: str, timeout: float = 5, **kw) -> dict:
    """Une requête au démon ; lève OSError s'il ne répond pas, DaemonError s'il refuse."""
    with socket.socket(socket.AF_UNIX) as s:
        s.settimeout(timeout)
        s.connect(str(SOCKET_PATH))
        s.sendall((json.dumps({"cmd": cmd, **kw}) + "\n").encode())
        buf = b""
        while not buf.endswith(b"\n"):
            chunk = s.recv(65536)
            if not chunk:
                break
            buf += chunk
    resp = json.loads(buf or b"{}")
    if not resp.get("ok"):
        raise DaemonError(resp.get("error", "réponse vide"))
    return resp


def ensure_daemon(wait: float = 4.0) -> bool:
    """Démon joignable et de la même version ; sinon le (re)démarre (service systemd --user, sinon
    processus détaché). Après une mise à jour du paquet, l'ancien démon tourne encore l'ancien code."""
    from rog_flare2_core import VERSION
    try:
        if request("ping", timeout=1).get("version") == VERSION:
            return True
        request("quit", timeout=1)
        for _ in range(30):  # attend que l'ancien démon libère le socket
            time.sleep(0.1)
            try:
                request("ping", timeout=0.5)
            except (OSError, DaemonError, ValueError):
                break
    except (OSError, DaemonError, ValueError):
        pass
    # Service systemd seulement pour le socket standard (pas pour un environnement de test isolé)
    standard = SOCKET_PATH.parent == Path(f"/run/user/{os.getuid()}") and not os.environ.get("FLATPAK_ID")
    try:
        started = standard and subprocess.run(["systemctl", "--user", "start", "animematrixd.service"],
                                              capture_output=True).returncode == 0
    except OSError:  # pas de systemctl (Flatpak, conteneur)
        started = False
    if not started:
        subprocess.Popen([sys.executable, str(Path(__file__).with_name("rog_flare2_demon.py"))],
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    deadline = time.monotonic() + wait
    while time.monotonic() < deadline:
        try:
            request("ping", timeout=1)
            return True
        except (OSError, DaemonError, ValueError):
            time.sleep(0.1)
    return False


def _value(text: str):
    try:
        return int(text)
    except ValueError:
        try:
            return float(text)
        except ValueError:
            return text


def end_message(code: int, seconds: int, command: str) -> str:
    """« Terminé : make 2 min 05 » ou « Échec (2) : make … »."""
    from rog_flare2_i18n import _
    word = command.split()[0].rsplit("/", 1)[-1] if command.split() else "?"
    m, s = divmod(max(0, seconds), 60)
    h, m = divmod(m, 60)
    took = f"{h} h {m:02d}" if h else f"{m} min {s:02d}" if m else f"{s} s"
    head = _("Terminé") if code == 0 else _("Échec ({code})").format(code=code)
    return f"{head} : {word} {took}"


def main(argv=None):
    ap = argparse.ArgumentParser(prog="animematrix-ctl", description="Commande le démon AniMe Matrix.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("etat")
    g = sub.add_parser("gif")
    g.add_argument("chemins", nargs="*")
    g.add_argument("--originaux", action="store_true")
    g.add_argument("--une-fois", action="store_true")
    g.add_argument("--fidele", action="store_true", help="géométrie fidèle (proportions gardées)")
    e = sub.add_parser("effet")
    e.add_argument("nom")
    e.add_argument("--param", action="append", default=[], metavar="clé=valeur")
    e.add_argument("--cadence", type=float, default=1.0)
    sub.add_parser("horloge")
    li = sub.add_parser("liste", help="joue une liste de lecture (sans nom : les affiche)")
    li.add_argument("nom", nargs="?")
    fa = sub.add_parser("favori", help="joue le favori numéro N (sans numéro : les affiche)")
    fa.add_argument("numero", nargs="?", type=int)
    t = sub.add_parser("texte")
    t.add_argument("message")
    n = sub.add_parser("notifier")
    n.add_argument("message")
    n.add_argument("--duree", type=float, default=6)
    f = sub.add_parser("fin", help="fin d'une commande longue (shell/animematrix-fin.sh)")
    f.add_argument("code", type=int)
    f.add_argument("secondes", type=int)
    f.add_argument("commande", nargs="+")
    b = sub.add_parser("luminosite")
    b.add_argument("valeur", type=int)
    sub.add_parser("stop")
    sub.add_parser("derniere")
    m = sub.add_parser("memoire", help="enregistre un GIF, une image ou un .bin dans la mémoire du clavier")
    m.add_argument("fichier")
    m.add_argument("--reduire", choices=("couper", "alterner"), default="couper",
                   help="au-delà de 196 images : garder le début, ou retirer une image sur deux")
    m.add_argument("--fidele", action="store_true", help="géométrie fidèle (proportions gardées)")
    sv = sub.add_parser("sauvegarde", help="exporte tous les réglages dans un .zip")
    sv.add_argument("fichier")
    sv.add_argument("--secrets", action="store_true", help="inclure le jeton de la télécommande et le mot de passe OBS")
    rs = sub.add_parser("restaurer", help="remplace les réglages par ceux d'un .zip (les actuels sont sauvegardés)")
    rs.add_argument("fichier")
    k = sub.add_parser("clavier", help="animation du clavier : 7 l'enregistrée (défaut), 1-6 les intégrées")
    k.add_argument("effet", nargs="?", type=int, default=7, choices=range(1, 8))
    from rog_flare2_rgb import DIRECTIONS, EFFECTS, SOFTWARE_MODES
    r = sub.add_parser("rgb", help="couleurs des touches : effet du clavier, ou theme / pulsation / ecran / audio")
    r.add_argument("effet", choices=[*EFFECTS, *SOFTWARE_MODES, "off"])
    r.add_argument("--couleur", action="append", default=[], metavar="#rrggbb", help="répétable (dégradés)")
    r.add_argument("--vitesse", type=int, help="0 (lent) à 100 (rapide)")
    r.add_argument("--luminosite", type=int, help="0 à 100, par crans de 25")
    r.add_argument("--direction", choices=list(DIRECTIONS))
    r.add_argument("--aleatoire", action="store_true", help="couleurs aléatoires")
    r.add_argument("--sans-enregistrer", action="store_true", help="perdu au débranchement")
    sub.add_parser("quitter")
    args = ap.parse_args(argv)
    if args.cmd in ("sauvegarde", "restaurer"):  # sans le démon
        import rog_flare2_sauvegarde as backup
        if args.cmd == "sauvegarde":
            print(f"{backup.export(Path(args.fichier), args.secrets)} fichiers → {args.fichier}")
            return
        n, before = backup.restore(Path(args.fichier))
        print(f"{n} fichiers restaurés" + (f" (anciens réglages : {before})" if before else ""))
        try:
            request("config", timeout=2)
        except (OSError, DaemonError, ValueError):
            pass
        return

    if not ensure_daemon():
        sys.exit("animematrixd injoignable")
    if args.cmd == "etat":
        print(json.dumps(request("status"), ensure_ascii=False, indent=1))
        return
    if args.cmd == "gif":
        from rog_flare2_core import gallery_dir, media_files, MEDIA_EXTENSIONS
        paths = [Path(p).expanduser() for p in args.chemins] or [gallery_dir()]
        files = []
        for p in paths:
            files += media_files(p) if p.is_dir() else [p] if p.suffix.lower() in MEDIA_EXTENSIONS else []
        show = {"type": "gif", "files": [str(f) for f in files], "loop": not args.une_fois,
                "converted": not args.originaux, "fidele": args.fidele}
    elif args.cmd == "effet":
        params = dict(kv.split("=", 1) for kv in args.param)
        show = {"type": "effet", "name": args.nom, "params": {k: _value(v) for k, v in params.items()},
                "speed": args.cadence}
    elif args.cmd == "horloge":
        show = {"type": "horloge"}
    elif args.cmd == "clavier":
        show = {"type": "clavier", "effet": args.effet}
    elif args.cmd == "rgb":
        if args.effet in (*SOFTWARE_MODES, "off"):
            config = {"mode": args.effet}
        else:
            config = {"mode": "clavier", "effet": args.effet, "couleurs": args.couleur, "aleatoire": args.aleatoire}
            config.update({k: v for k, v in (("vitesse", args.vitesse), ("luminosite", args.luminosite),
                                             ("direction", args.direction)) if v is not None})
        request("rgb", timeout=10, config=config, save=not args.sans_enregistrer)
        return
    elif args.cmd == "memoire":
        r = request("memoire", timeout=60, file=str(Path(args.fichier).expanduser().resolve()),
                    reduire=args.reduire, fidele=args.fidele)
        print(f"{r['images']} images, {r['blocs']} blocs, {r['tentatives']} tentative(s)")
        return
    elif args.cmd in ("liste", "favori"):
        from rog_flare2_listes import load_favorites, load_lists
        if args.cmd == "liste":
            names = sorted(load_lists())
            if not args.nom:
                print("\n".join(names))
                return
            show = {"type": "liste", "name": args.nom}
        else:
            favorites = load_favorites()
            if args.numero is None:
                print("\n".join(f"{i}. {f.get('label', '?')}" for i, f in enumerate(favorites, 1)))
                return
            if not 1 <= args.numero <= len(favorites):
                sys.exit(f"favori {args.numero} introuvable")
            show = favorites[args.numero - 1]["show"]
    elif args.cmd == "texte":
        show = {"type": "effet", "name": "Scroll Text", "params": {"message": args.message}, "speed": 1.0}
    elif args.cmd == "derniere":
        show = json.loads(SHOW_FILE.read_text(encoding="utf-8"))
    elif args.cmd == "notifier":
        request("notify", text=args.message, duration=args.duree)
        return
    elif args.cmd == "fin":
        request("notify", text=end_message(args.code, args.secondes, " ".join(args.commande)), duration=0)
        return
    elif args.cmd == "quitter":
        request("quit")
        return
    elif args.cmd == "luminosite":
        request("brightness", value=args.valeur)
        return
    else:
        request("stop")
        return
    request("play", show=show)


if __name__ == "__main__":
    main()
